# DOSH Chemical Register — patch set

Found your existing implementation: `server/routes/chemicals.js` (`GET /reports/dosh-register-data`)
+ `public/js/pages/chemical.module.js` (`renderDoshReport`, registered at `/chemical/dosh-register`).
These 3 files replace/extend those to match the guideline's Appendix 4/5 layout exactly.

## Files
- `dosh-register-data.route.js` — drop-in replacement for the `/reports/dosh-register-data` handler in `server/routes/chemicals.js`. Adds Physical Form + Active Ingredients (joined from Substances/current SDS) to each row.
- `dosh-report.render.js` — drop-in replacement for the `renderDoshReport` function + its `Router.register("/chemical/dosh-register", ...)` block in `public/js/pages/chemical.module.js`. Section A is its own printed page; Section B/C are grouped-header, auto-paginating pages (8 rows/page) matching Appendix 4/5; adds a working "Export Excel" button (ExcelJS, loaded from CDN) alongside the existing Print button.
- `dosh-register.css` — additions to `public/css/styles.css` (landscape print, page-per-section, grouped header cells). Your existing `.dosh-table`/`@media print` rules stay; these are additive.

## Gaps — no corresponding Airtable field yet
The guideline table has 3 columns your schema doesn't store anywhere:
- **Type#** and **Class** — a coded hazard type/class (distinct from your free-text "Hazard Classification"). Not in `chemicals` or `substances`.
- **Complies with CPL Regulation 1977 (Y/N)** — patch renders this as "—" for now; easiest fix is a new Yes/No field on `chemicals` (or infer it from Label Inspection's `compliant`, which the patch does NOT do since that's a different compliance check).

Add those fields to Airtable + `server/lib/schema.js`'s `chemicals.fields` and I'll wire them in — didn't want to guess field IDs.

## Not done in this pass (flagged, not built)
- **Reusable multi-register export framework** (Noise/Machinery/CAPA/Committee/Training). Chemical Register now works end-to-end; generalizing needs a config object per register (columns, section labels, data endpoint) driving one shared PDF+Excel renderer instead of each module hardcoding its own `render*Report`. Say the word and which register to prototype second, and I'll build the shared engine against real code, not guesses.
- Excel export today is client-side only (button click, ExcelJS via CDN) — no server endpoint. Fine for on-demand exports; a server-generated file (for e.g. scheduled/emailed reports) would be a separate endpoint.
